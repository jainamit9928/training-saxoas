function partialRight(input) {
    var slice = Array.prototype.slice;
    var args = slice.call(arguments, 1);
    return function() {
        return input.apply(undefined, slice.call(arguments, 0).concat(args));
    }
}



function curry(f, n) {
    var slice = Array.prototype.slice;
    var args = slice.call(arguments, 0);
    if (typeof n !== 'number')
        args[1] = f.length;
    if (n === args.length - 2)
        return f.apply(undefined, args.slice(2));
    return function() {
        return curry.apply(undefined, args.concat(slice.call(arguments, 0)));
    };
}
Array.prototype.myReduce = function(fn,defaultValue){
  var self =this;
  var accumlator = defaultValue;
  console.log(self);
  self.forEach(function(value,index){
    if(accumlator == undefined){
      accumlator =value;
    }
    accumlator =fn.call(undefined,accumlator,value,index,self);
  })
  return accumlator;

}
var b = curry(function(a, b, c) { return a + b + c });
b(1)(2)(3);

var setting = window.setting || {};

setting =(function(){
  function setSettings(path,value,option){
    this.path = path;
    this.value = value;
    this.option =option;
    this.state ={};

  }
  function createNestedObject = function( state, paths, value ) {
    var path = arguments.length === 3 ? paths.pop() : false;
    for( var i = 0; i < paths.length; i++ ) {
        state = state[ paths[i] ] = state[ paths[i] ] || {};
    }
    if( path ) state = state[ path ] = value;
    return state;
};
function recLookup(obj, path) {
       parts = path.split(".");
       if (parts.length==1){
           return obj[parts[0]];
       }
       return recLookup(obj[parts[0]], parts.slice(1).join("."));
   }
   var deep_value = function(obj, path){
    for (var i=0, path=path.split('.'), len=path.length; i<len; i++){
        obj = obj[path[i]];
    };
    return obj;
};
setSettings.prototype.updateState = function(path,value,option){
var state = createNestedObject(path,value,option);
}
return setSettings;
})()
