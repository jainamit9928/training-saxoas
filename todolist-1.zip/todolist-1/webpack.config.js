const path = require('path');
const webpackValidator = require("webpack-validator");

module.exports = (env) => {
    console.log("enviorment is" + env);
    return {
        context: path.resolve('app'),
        entry: {
            entry: path.resolve(__dirname, 'app', 'js', 'app.jsx')
        },
        output: {
            path: path.resolve(__dirname, 'dist'),
            filename: "app.js",
            publicPath: ""
        },
        resolve: {
            extensions: ['.js', '.jsx']
        },
        devServer: {
            port: 9000,
            contentBase: "app"
        },
        devtool: env.prod ? "source-map" : "eval",
        module: {
            rules: [{
                test: [/\.js$/, /\.jsx$/],
                exclude: /(node_modules)/,
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['es2015', 'react']
                    }
                }
            }]
        }
    }
}