import React from 'react';
import ReactDOM from 'react-dom';
import Todos from './Todos';
import FilterLink from './FilterLink';
import getVisibleTodos from '../../actions/action';
export default class TodoApp extends React.Component {
  constructor(props){
    super(props)
   //this.getVisibleTodos = this. getVisibleTodos.bind(this)
  }
 



  render(){
    const {todos,visibilityFilter} = this.props;
    let visibleTodos = getVisibleTodos(todos,visibilityFilter);
    console.log(visibleTodos);
    return (
      <div>
    <input type="text" ref={node => {
      this.input=node} 
      }/>
     
     <button onClick ={ () => {
       this.props.executeStore.dispatch({type:"ADD_TODO",text:this.input.value});
        this.input.value =""
       }
       
       }>Add Todo</button> 
    <Todos todos ={visibleTodos} onTodoClick ={(id) => this.props.executeStore.dispatch({type:"TOGGLE_TODO",id}) }/>
    <p>
      Show :
       {' '}
    <FilterLink customStore = {this.props.executeStore} filter ="SHOW_ALL" currentVisibiltyFilter ={visibilityFilter} >ALL</FilterLink>
     {' '}
    <FilterLink customStore = {this.props.executeStore} filter ="SHOW_ACTIVE" currentVisibiltyFilter ={visibilityFilter}>Active</FilterLink>
     {' '}
    <FilterLink customStore = {this.props.executeStore} filter ="SHOW_COMPLETED" currentVisibiltyFilter ={visibilityFilter}>Completed</FilterLink>
    </p>
    </div>
  )
  
  }

}


